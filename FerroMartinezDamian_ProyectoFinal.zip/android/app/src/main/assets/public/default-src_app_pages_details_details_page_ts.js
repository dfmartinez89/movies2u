"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_pages_details_details_page_ts"],{

/***/ 5362:
/*!***********************************************!*\
  !*** ./src/app/pages/details/details.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailsPage": () => (/* binding */ DetailsPage)
/* harmony export */ });
/* harmony import */ var _home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./details.page.html?ngResource */ 6366);
/* harmony import */ var _details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./details.page.scss?ngResource */ 791);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_movies_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/movies.service */ 4550);
/* harmony import */ var _reviews_reviews_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../reviews/reviews.page */ 1539);
/* harmony import */ var _edit_movie_edit_movie_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../edit-movie/edit-movie.page */ 7990);









let DetailsPage = class DetailsPage {
  constructor(moviesService, modalCtrl, actionSheetCtrl) {
    this.moviesService = moviesService;
    this.modalCtrl = modalCtrl;
    this.actionSheetCtrl = actionSheetCtrl;
    this.swiperOpts = {
      slidesPerView: 1.3,
      freeMode: true,
      spaceBetween: -5
    };
  }

  ngOnInit() {
    this.moviesService.getMovieDetails(this.id).subscribe(resp => {
      this.movie = resp.data;
      this.reviews = resp.data.reviews;
    });
  }

  addReview(id) {
    var _this = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.modalCtrl.dismiss();

      const modal = yield _this.modalCtrl.create({
        component: _reviews_reviews_page__WEBPACK_IMPORTED_MODULE_4__.ReviewsPage,
        componentProps: {
          id
        }
      });
      modal.present();
    })();
  }

  back() {
    this.modalCtrl.dismiss();
  }

  onOpenMenu(id) {
    var _this2 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const actionSheet = yield _this2.actionSheetCtrl.create({
        header: 'Options',
        buttons: [{
          text: 'Delete',
          role: 'destructive',
          icon: 'trash',
          handler: () => {
            _this2.deleteReview(id);
          }
        }]
      });
      yield actionSheet.present();
    })();
  }

  deleteReview(reviewid) {
    var _this3 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield (yield _this3.moviesService.deleteReview(_this3.id, reviewid)).subscribe(() => {
        _this3.modalCtrl.dismiss();
      });
    })();
  }

  deleteMovie(id) {
    var _this4 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      (yield _this4.moviesService.deleteMovie(id)).subscribe(() => {
        console.log('deleted', id);

        _this4.modalCtrl.dismiss();
      });
    })();
  }

  onOpenDeleteMenu(id) {
    var _this5 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const actionSheet = yield _this5.actionSheetCtrl.create({
        header: 'Options',
        buttons: [{
          text: 'Delete the movie',
          role: 'destructive',
          icon: 'trash',
          handler: () => {
            _this5.deleteMovie(id);
          }
        }]
      });
      yield actionSheet.present();
    })();
  }

  editMovie(id) {
    var _this6 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this6.modalCtrl.dismiss();

      const modal = yield _this6.modalCtrl.create({
        component: _edit_movie_edit_movie_page__WEBPACK_IMPORTED_MODULE_5__.EditMoviePage,
        componentProps: {
          id
        }
      });
      modal.present();
    })();
  }

};

DetailsPage.ctorParameters = () => [{
  type: _services_movies_service__WEBPACK_IMPORTED_MODULE_3__.MoviesService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
}];

DetailsPage.propDecorators = {
  id: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input
  }]
};
DetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-details',
  template: _details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], DetailsPage);


/***/ }),

/***/ 7990:
/*!*****************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditMoviePage": () => (/* binding */ EditMoviePage)
/* harmony export */ });
/* harmony import */ var _home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _edit_movie_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-movie.page.html?ngResource */ 8439);
/* harmony import */ var _edit_movie_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-movie.page.scss?ngResource */ 8205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_movies_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/movies.service */ 4550);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/camera */ 4241);











let EditMoviePage = class EditMoviePage {
  constructor(formBuilder, navCtrl, moviesService, sanitizer, modalCtrl) {
    this.formBuilder = formBuilder;
    this.navCtrl = navCtrl;
    this.moviesService = moviesService;
    this.sanitizer = sanitizer;
    this.modalCtrl = modalCtrl;
    this.errorMessages = {
      location: [{
        type: 'required',
        message: 'Location is required'
      }, {
        type: 'minlength',
        message: 'Location must be at least 5 characters long'
      }, {
        type: 'maxlength',
        message: 'Location cannot be more than 100 characters long'
      }],
      title: [{
        type: 'required',
        message: 'Title is required'
      }, {
        type: 'minlength',
        message: 'Title must be at least 3 characters long'
      }, {
        type: 'maxlength',
        message: 'Title cannot be more than 200 characters long'
      }],
      rating: [{
        type: 'required',
        message: 'Rating is required'
      }, {
        type: 'min',
        message: 'Rating must be at least 1'
      }],
      genre: [{
        type: 'required',
        message: 'Genre is required'
      }, {
        type: 'minlength',
        message: 'Description must be at least 4 characters long'
      }, {
        type: 'maxlength',
        message: 'Genre cannot be more than 100 characters long'
      }],
      year: [{
        type: 'required',
        message: 'Year is required'
      }],
      poster: [{
        type: 'required',
        message: 'Poster is required'
      }]
    };
  }

  ngOnInit() {
    this.moviesService.getMovieDetails(this.id).subscribe(resp => {
      this.movie = resp.data;
    });
    this.photo = '../../../assets/avatars/av-4.png';
    this.movieForm = this.formBuilder.group({
      location: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.geoLocation, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      rating: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[1-5]'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      title: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.title, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(200), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      genre: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.genre, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      year: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.year, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      poster: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.poster, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]))
    });
  }
  /**
   * submit the movie
   */


  submit(value) {
    var _this = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield (yield _this.moviesService.addMovie(value)).subscribe(() => {
        _this.navCtrl.navigateRoot('/main/tabs/tab1');
      });
    })();
  }

  getLocation() {
    var _this2 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const position = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();
      _this2.latitude = position.coords.latitude;
      _this2.longitude = position.coords.longitude;
      _this2.accuracy = position.coords.accuracy;
    })();
  }

  takePicture() {
    var _this3 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.Camera.getPhoto({
        quality: 100,
        allowEditing: false,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.CameraResultType.Uri
      });
      _this3.photo = _this3.sanitizer.bypassSecurityTrustResourceUrl(image && image.webPath);
    })();
  }

  back() {
    this.modalCtrl.dismiss();
  }

};

EditMoviePage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController
}, {
  type: src_app_services_movies_service__WEBPACK_IMPORTED_MODULE_3__.MoviesService
}, {
  type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}];

EditMoviePage.propDecorators = {
  id: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }]
};
EditMoviePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-edit-movie',
  template: _edit_movie_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_edit_movie_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], EditMoviePage);


/***/ }),

/***/ 1539:
/*!***********************************************!*\
  !*** ./src/app/pages/reviews/reviews.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPage": () => (/* binding */ ReviewsPage)
/* harmony export */ });
/* harmony import */ var _home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _reviews_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reviews.page.html?ngResource */ 6291);
/* harmony import */ var _reviews_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reviews.page.scss?ngResource */ 6946);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _services_movies_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/movies.service */ 4550);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/camera */ 4241);











let ReviewsPage = class ReviewsPage {
  constructor(modalCtrl, formBuilder, moviesService, sanitizer) {
    this.modalCtrl = modalCtrl;
    this.formBuilder = formBuilder;
    this.moviesService = moviesService;
    this.sanitizer = sanitizer;
    this.errorMessages = {
      reviewLocation: [{
        type: 'required',
        message: 'Location is required'
      }, {
        type: 'minlength',
        message: 'Location must be at least 5 characters long'
      }, {
        type: 'maxlength',
        message: 'Location cannot be more than 100 characters long'
      }],
      author: [{
        type: 'required',
        message: 'Author is required'
      }, {
        type: 'minlength',
        message: 'Author must be at least 3 characters long'
      }, {
        type: 'maxlength',
        message: 'Author cannot be more than 30 characters long'
      }],
      rating: [{
        type: 'required',
        message: 'Rating is required'
      }, {
        type: 'min',
        message: 'Rating must be at least 1'
      }],
      description: [{
        type: 'required',
        message: 'Description is required'
      }, {
        type: 'minlength',
        message: 'Description must be at least 4 characters long'
      }, {
        type: 'maxlength',
        message: 'Description cannot be more than 200 characters long'
      }]
    };
  }

  ngOnInit() {
    this.photo = '../../../assets/avatars/av-4.png';
    this.reviewForm = this.formBuilder.group({
      author: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(50), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      rating: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[1-5]'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      description: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(200), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      reviewLocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]))
    });
  }

  back() {
    this.modalCtrl.dismiss();
  }
  /**
   * submit the review
   */


  submit(value) {
    this.moviesService.addReview(this.id, value).subscribe(() => {
      this.modalCtrl.dismiss();
    });
  }

  getLocation() {
    var _this = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const position = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();
      _this.latitude = position.coords.latitude;
      _this.longitude = position.coords.longitude;
      _this.accuracy = position.coords.accuracy;
    })();
  }

  takePicture() {
    var _this2 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.Camera.getPhoto({
        quality: 100,
        allowEditing: false,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.CameraResultType.Uri
      });
      _this2.photo = _this2.sanitizer.bypassSecurityTrustResourceUrl(image && image.webPath);
    })();
  }

};

ReviewsPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormBuilder
}, {
  type: _services_movies_service__WEBPACK_IMPORTED_MODULE_3__.MoviesService
}, {
  type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer
}];

ReviewsPage.propDecorators = {
  id: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }]
};
ReviewsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-reviews',
  template: _reviews_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_reviews_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ReviewsPage);


/***/ }),

/***/ 791:
/*!************************************************************!*\
  !*** ./src/app/pages/details/details.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = ".poster-detail {\n  position: relative;\n  top: -75px;\n  left: -10px;\n  margin-bottom: -75px;\n}\n\n.title {\n  text-align: center;\n  width: 100%;\n  position: absolute;\n  color: white;\n  padding: 5px 5px 40px 5px;\n  /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#000000+0,000000+100&0.65+0,0+100;Neutral+Density */\n  /* FF3.6-15 */\n  /* Chrome10-25,Safari5.1-6 */\n  background: linear-gradient(to bottom, rgba(0, 0, 0, 0.65) 0%, rgba(0, 0, 0, 0) 100%);\n  /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */\n  filter: progid:DXImageTransform.Microsoft.gradient( startColorstr=\"#a6000000\", endColorstr=\"#00000000\",GradientType=0 );\n  /* IE6-9 */\n}\n\n.title h1 {\n  position: absolute;\n  top: 28px;\n  left: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0FBQUo7O0FBR0E7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUdBLDZJQUFBO0VBQ2dGLGFBQUE7RUFDRSw0QkFBQTtFQUNsRixxRkFBQTtFQUFnRixxREFBQTtFQUNoRix1SEFBQTtFQUF5SCxVQUFBO0FBRTdIOztBQUNBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsU0FBQTtBQUVKIiwiZmlsZSI6ImRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4ucG9zdGVyLWRldGFpbCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRvcDogLTc1cHg7XG4gICAgbGVmdDogLTEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogLTc1cHg7XG59XG5cbi50aXRsZSB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgcGFkZGluZzogNXB4IDVweCA0MHB4IDVweDtcblxuXG4gICAgLyogUGVybWFsaW5rIC0gdXNlIHRvIGVkaXQgYW5kIHNoYXJlIHRoaXMgZ3JhZGllbnQ6IGh0dHA6Ly9jb2xvcnppbGxhLmNvbS9ncmFkaWVudC1lZGl0b3IvIzAwMDAwMCswLDAwMDAwMCsxMDAmMC42NSswLDArMTAwO05ldXRyYWwrRGVuc2l0eSAqL1xuICAgIGJhY2tncm91bmQ6IC1tb3otbGluZWFyLWdyYWRpZW50KHRvcCwgcmdiYSgwLDAsMCwwLjY1KSAwJSwgcmdiYSgwLDAsMCwwKSAxMDAlKTsgLyogRkYzLjYtMTUgKi9cbiAgICBiYWNrZ3JvdW5kOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCh0b3AsIHJnYmEoMCwwLDAsMC42NSkgMCUscmdiYSgwLDAsMCwwKSAxMDAlKTsgLyogQ2hyb21lMTAtMjUsU2FmYXJpNS4xLTYgKi9cbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCByZ2JhKDAsMCwwLDAuNjUpIDAlLHJnYmEoMCwwLDAsMCkgMTAwJSk7IC8qIFczQywgSUUxMCssIEZGMTYrLCBDaHJvbWUyNissIE9wZXJhMTIrLCBTYWZhcmk3KyAqL1xuICAgIGZpbHRlcjogcHJvZ2lkOkRYSW1hZ2VUcmFuc2Zvcm0uTWljcm9zb2Z0LmdyYWRpZW50KCBzdGFydENvbG9yc3RyPScjYTYwMDAwMDAnLCBlbmRDb2xvcnN0cj0nIzAwMDAwMDAwJyxHcmFkaWVudFR5cGU9MCApOyAvKiBJRTYtOSAqL1xufVxuXG4udGl0bGUgaDF7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMjhweDtcbiAgICBsZWZ0OiA1cHg7XG59XG4iXX0= */";

/***/ }),

/***/ 8205:
/*!******************************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LW1vdmllLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 6946:
/*!************************************************************!*\
  !*** ./src/app/pages/reviews/reviews.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXZpZXdzLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 6366:
/*!************************************************************!*\
  !*** ./src/app/pages/details/details.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"secondary\">\n    <ion-title>Movie Details</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button [routerLink]=\"['/login']\">\n        <ion-icon name=\"person-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" class=\"ion-no-margin ion-no-border\">\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"12\">\n        <ion-card>\n          <ion-label class=\"title\">\n            <h1>{{movie.title}}</h1>\n          </ion-label>\n          <img [src]=\"movie.poster\" alt=\"\" />\n        </ion-card>\n      </ion-col>\n    </ion-row>\n\n    <ion-row>\n      <ion-col size=\"7\">\n        <ion-chip color=\"primary\" mode=\"ios\" outline=\"true\">\n          <ion-label>{{movie.genre}}</ion-label>\n        </ion-chip>\n      </ion-col>\n      <ion-col size=\"2\">\n        <ion-chip color=\"secondary\" mode=\"ios\" outline=\"true\">\n          <ion-label>{{movie.year}}</ion-label>\n        </ion-chip>\n      </ion-col>\n      <ion-col size=\"3\">\n        <ion-chip color=\"primary\" mode=\"ios\" outline=\"true\">\n          <ion-label>{{movie.rating}}</ion-label>\n        </ion-chip>\n      </ion-col>\n    </ion-row>\n\n    <swiper [config]=\"swiperOpts\">\n      <ng-template swiperSlide *ngFor=\"let pair of reviews | pair\">\n        <ion-row>\n          <ion-col size=\"12\" *ngFor=\"let review of pair\">\n            <ion-card\n              color=\"terciary\"\n              mode=\"ios\"\n              outline=\"true\"\n              class=\"ion-text-center\"\n              ><ion-row>\n                <ion-col align=\"right\">\n                  <ion-button (click)=\"onOpenMenu(review._id)\" fill=\"clear\">\n                    <ion-icon\n                      slot=\"icon-only\"\n                      name=\"ellipsis-vertical-outline\"\n                    ></ion-icon>\n                  </ion-button>\n                </ion-col>\n              </ion-row>\n              <ion-card-subtitle>{{review.author}}</ion-card-subtitle>\n\n              <ion-card-subtitle>{{review.rating}}</ion-card-subtitle>\n              <ion-card-content> {{review.description}} </ion-card-content>\n            </ion-card>\n          </ion-col>\n        </ion-row>\n      </ng-template>\n    </swiper>\n  </ion-grid>\n</ion-content>\n\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"start\" name=\"arrow-undo-outline\"></ion-icon>\n        <ion-label>Back</ion-label>\n      </ion-button>\n      <ion-button (click)=\"editMovie(movie._id)\">\n        <ion-icon slot=\"start\" name=\"pencil-outline\"></ion-icon>\n        <ion-label>Edit</ion-label>\n      </ion-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"onOpenDeleteMenu(movie._id)\">\n        <ion-icon slot=\"start\" name=\"trash-outline\"></ion-icon>\n        <ion-label>Delete</ion-label>\n      </ion-button>\n      <ion-button (click)=\"addReview(movie._id)\">\n        <ion-icon slot=\"start\" name=\"create-outline\"></ion-icon>\n        <ion-label>Review</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ }),

/***/ 8439:
/*!******************************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"primary\">\n    <ion-title> New Movie </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button [routerLink]=\"['/login']\">\n        <ion-icon name=\"person-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"movieForm\" (ngSubmit)=\"submit(movieForm.value)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"fixed\">Title</ion-label>\n        <ion-input autocapitalize type=\"text\" formControlName=\"title\" required [placeholder]=\" movie.title\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.title\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('title').hasError(error.type) && (movieForm.get('title').dirty || movieForm.get('title').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Genre</ion-label>\n        <ion-input autocapitalize type=\"text\" formControlName=\"genre\" required [placeholder]=\" movie.genre\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.genre\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('genre').hasError(error.type) && (movieForm.get('genre').dirty || movieForm.get('genre').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Year</ion-label>\n        <ion-input type=\"text\" formControlName=\"year\" required [placeholder]=\" movie.year\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.year\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('year').hasError(error.type) && (movieForm.get('year').dirty || movieForm.get('year').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Rating</ion-label>\n        <ion-input type=\"number\" formControlName=\"rating\" required [placeholder]=\" movie.rating\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.rating\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('rating').hasError(error.type) && (movieForm.get('rating').dirty || movieForm.get('rating').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Location</ion-label>\n        <ion-input type=\"text\" formControlName=\"location\" required [placeholder]=\"movie.geoLocation.formattedLocation\"></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.location\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('location').hasError(error.type) && (movieForm.get('location').dirty || movieForm.get('location').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Poster</ion-label>\n        <ion-input type=\"text\" formControlName=\"poster\" required [placeholder]=\" movie.poster\"></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.poster\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('poster').hasError(error.type) && (movieForm.get('poster').dirty || movieForm.get('poster').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-button type=\"submit\" expand=\"block\" [disabled]=\"!movieForm.valid\">\n        <ion-icon slot=\"end\" name=\"cloud-upload-outline\"></ion-icon>\n      </ion-button>\n    </ion-list>\n  </form>\n\n  <ion-card>\n    <ion-card-content>\n      <img alt=\"Photo\" [src]=\"photo\" />\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"takePicture()\">\n      <ion-icon name=\"camera\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <div id=\"container\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-subtitle>Coordinates</ion-card-subtitle>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>Latitude: {{ latitude }}</ion-item>\n        <ion-item>Longitude: {{ longitude }}</ion-item>\n        <ion-item>Accuracy: {{ accuracy }}</ion-item>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"start\" name=\"arrow-undo-outline\"></ion-icon>\n        <ion-label>Back</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ }),

/***/ 6291:
/*!************************************************************!*\
  !*** ./src/app/pages/reviews/reviews.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"secondary\">\n    <ion-title>Movie Review</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"reviewForm\" (ngSubmit)=\"submit(reviewForm.value)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Author</ion-label>\n        <ion-input\n          autocapitalize\n          type=\"text\"\n          formControlName=\"author\"\n          required\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.author\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('author').hasError(error.type) && (reviewForm.get('author').dirty || reviewForm.get('author').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Description</ion-label>\n        <ion-input\n          type=\"text\"\n          formControlName=\"description\"\n          required\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.description\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('description').hasError(error.type) && (reviewForm.get('description').dirty || reviewForm.get('description').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Rating</ion-label>\n        <ion-input type=\"number\" formControlName=\"rating\" required></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.rating\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('rating').hasError(error.type) && (reviewForm.get('rating').dirty || reviewForm.get('rating').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Location</ion-label>\n        <ion-input\n          type=\"text\"\n          formControlName=\"reviewLocation\"\n          required\n          (ionChange)=\"getLocation()\"\n          [debounce]=\"500\"\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.reviewLocation\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('reviewLocation').hasError(error.type) && (reviewForm.get('reviewLocation').dirty || reviewForm.get('reviewLocation').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-button type=\"submit\" expand=\"block\" [disabled]=\"!reviewForm.valid\">\n        <ion-icon slot=\"end\" name=\"cloud-upload-outline\"></ion-icon>\n      </ion-button>\n    </ion-list>\n  </form>\n\n  <ion-card>\n    <ion-card-content>\n      <img alt=\"Photo\" [src]=\"photo\" />\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"takePicture()\">\n      <ion-icon name=\"camera\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <div id=\"container\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>Coordinates</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>Latitude: {{ latitude }}</ion-item>\n        <ion-item>Longitude: {{ longitude }}</ion-item>\n        <ion-item>Accuracy: {{ accuracy }}</ion-item>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"start\" name=\"arrow-undo-outline\"></ion-icon>\n        <ion-label>Back</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_pages_details_details_page_ts.js.map