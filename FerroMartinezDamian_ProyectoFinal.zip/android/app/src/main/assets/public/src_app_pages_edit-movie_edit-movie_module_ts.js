"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_edit-movie_edit-movie_module_ts"],{

/***/ 2839:
/*!***************************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditMoviePageRoutingModule": () => (/* binding */ EditMoviePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _edit_movie_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-movie.page */ 7990);




const routes = [
    {
        path: '',
        component: _edit_movie_page__WEBPACK_IMPORTED_MODULE_0__.EditMoviePage
    }
];
let EditMoviePageRoutingModule = class EditMoviePageRoutingModule {
};
EditMoviePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EditMoviePageRoutingModule);



/***/ }),

/***/ 1064:
/*!*******************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditMoviePageModule": () => (/* binding */ EditMoviePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _edit_movie_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./edit-movie-routing.module */ 2839);
/* harmony import */ var _edit_movie_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-movie.page */ 7990);







let EditMoviePageModule = class EditMoviePageModule {
};
EditMoviePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _edit_movie_routing_module__WEBPACK_IMPORTED_MODULE_0__.EditMoviePageRoutingModule,
        ],
        providers: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder],
        declarations: [_edit_movie_page__WEBPACK_IMPORTED_MODULE_1__.EditMoviePage],
    })
], EditMoviePageModule);



/***/ }),

/***/ 7990:
/*!*****************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditMoviePage": () => (/* binding */ EditMoviePage)
/* harmony export */ });
/* harmony import */ var _home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _edit_movie_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit-movie.page.html?ngResource */ 8439);
/* harmony import */ var _edit_movie_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-movie.page.scss?ngResource */ 8205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_movies_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/movies.service */ 4550);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/camera */ 4241);











let EditMoviePage = class EditMoviePage {
  constructor(formBuilder, navCtrl, moviesService, sanitizer, modalCtrl) {
    this.formBuilder = formBuilder;
    this.navCtrl = navCtrl;
    this.moviesService = moviesService;
    this.sanitizer = sanitizer;
    this.modalCtrl = modalCtrl;
    this.errorMessages = {
      location: [{
        type: 'required',
        message: 'Location is required'
      }, {
        type: 'minlength',
        message: 'Location must be at least 5 characters long'
      }, {
        type: 'maxlength',
        message: 'Location cannot be more than 100 characters long'
      }],
      title: [{
        type: 'required',
        message: 'Title is required'
      }, {
        type: 'minlength',
        message: 'Title must be at least 3 characters long'
      }, {
        type: 'maxlength',
        message: 'Title cannot be more than 200 characters long'
      }],
      rating: [{
        type: 'required',
        message: 'Rating is required'
      }, {
        type: 'min',
        message: 'Rating must be at least 1'
      }],
      genre: [{
        type: 'required',
        message: 'Genre is required'
      }, {
        type: 'minlength',
        message: 'Description must be at least 4 characters long'
      }, {
        type: 'maxlength',
        message: 'Genre cannot be more than 100 characters long'
      }],
      year: [{
        type: 'required',
        message: 'Year is required'
      }],
      poster: [{
        type: 'required',
        message: 'Poster is required'
      }]
    };
  }

  ngOnInit() {
    this.moviesService.getMovieDetails(this.id).subscribe(resp => {
      this.movie = resp.data;
    });
    this.photo = '../../../assets/avatars/av-4.png';
    this.movieForm = this.formBuilder.group({
      location: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.geoLocation, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      rating: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[1-5]'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      title: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.title, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(200), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      genre: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.genre, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      year: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.year, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      poster: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl(this.movie.poster, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]))
    });
  }
  /**
   * submit the movie
   */


  submit(value) {
    var _this = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield (yield _this.moviesService.addMovie(value)).subscribe(() => {
        _this.navCtrl.navigateRoot('/main/tabs/tab1');
      });
    })();
  }

  getLocation() {
    var _this2 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const position = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();
      _this2.latitude = position.coords.latitude;
      _this2.longitude = position.coords.longitude;
      _this2.accuracy = position.coords.accuracy;
    })();
  }

  takePicture() {
    var _this3 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.Camera.getPhoto({
        quality: 100,
        allowEditing: false,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.CameraResultType.Uri
      });
      _this3.photo = _this3.sanitizer.bypassSecurityTrustResourceUrl(image && image.webPath);
    })();
  }

  back() {
    this.modalCtrl.dismiss();
  }

};

EditMoviePage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController
}, {
  type: src_app_services_movies_service__WEBPACK_IMPORTED_MODULE_3__.MoviesService
}, {
  type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}];

EditMoviePage.propDecorators = {
  id: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }]
};
EditMoviePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-edit-movie',
  template: _edit_movie_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_edit_movie_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], EditMoviePage);


/***/ }),

/***/ 8205:
/*!******************************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0LW1vdmllLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 8439:
/*!******************************************************************!*\
  !*** ./src/app/pages/edit-movie/edit-movie.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"primary\">\n    <ion-title> New Movie </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button [routerLink]=\"['/login']\">\n        <ion-icon name=\"person-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"movieForm\" (ngSubmit)=\"submit(movieForm.value)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"fixed\">Title</ion-label>\n        <ion-input autocapitalize type=\"text\" formControlName=\"title\" required [placeholder]=\" movie.title\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.title\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('title').hasError(error.type) && (movieForm.get('title').dirty || movieForm.get('title').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Genre</ion-label>\n        <ion-input autocapitalize type=\"text\" formControlName=\"genre\" required [placeholder]=\" movie.genre\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.genre\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('genre').hasError(error.type) && (movieForm.get('genre').dirty || movieForm.get('genre').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Year</ion-label>\n        <ion-input type=\"text\" formControlName=\"year\" required [placeholder]=\" movie.year\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.year\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('year').hasError(error.type) && (movieForm.get('year').dirty || movieForm.get('year').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Rating</ion-label>\n        <ion-input type=\"number\" formControlName=\"rating\" required [placeholder]=\" movie.rating\"\n          ></ion-input\n        >\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.rating\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('rating').hasError(error.type) && (movieForm.get('rating').dirty || movieForm.get('rating').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Location</ion-label>\n        <ion-input type=\"text\" formControlName=\"location\" required [placeholder]=\"movie.geoLocation.formattedLocation\"></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.location\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('location').hasError(error.type) && (movieForm.get('location').dirty || movieForm.get('location').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"fixed\">Poster</ion-label>\n        <ion-input type=\"text\" formControlName=\"poster\" required [placeholder]=\" movie.poster\"></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.poster\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('poster').hasError(error.type) && (movieForm.get('poster').dirty || movieForm.get('poster').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-button type=\"submit\" expand=\"block\" [disabled]=\"!movieForm.valid\">\n        <ion-icon slot=\"end\" name=\"cloud-upload-outline\"></ion-icon>\n      </ion-button>\n    </ion-list>\n  </form>\n\n  <ion-card>\n    <ion-card-content>\n      <img alt=\"Photo\" [src]=\"photo\" />\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"takePicture()\">\n      <ion-icon name=\"camera\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <div id=\"container\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-subtitle>Coordinates</ion-card-subtitle>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>Latitude: {{ latitude }}</ion-item>\n        <ion-item>Longitude: {{ longitude }}</ion-item>\n        <ion-item>Accuracy: {{ accuracy }}</ion-item>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"start\" name=\"arrow-undo-outline\"></ion-icon>\n        <ion-label>Back</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_edit-movie_edit-movie_module_ts.js.map