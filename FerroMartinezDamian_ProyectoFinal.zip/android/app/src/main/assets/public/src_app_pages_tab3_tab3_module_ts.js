"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_tab3_tab3_module_ts"],{

/***/ 3546:
/*!***************************************************!*\
  !*** ./src/app/pages/tab3/tab3-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageRoutingModule": () => (/* binding */ Tab3PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 9648);




const routes = [
    {
        path: '',
        component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page,
    }
];
let Tab3PageRoutingModule = class Tab3PageRoutingModule {
};
Tab3PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab3PageRoutingModule);



/***/ }),

/***/ 2090:
/*!*******************************************!*\
  !*** ./src/app/pages/tab3/tab3.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3PageModule": () => (/* binding */ Tab3PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab3.page */ 9648);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 9885);
/* harmony import */ var _tab3_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab3-routing.module */ 3546);









let Tab3PageModule = class Tab3PageModule {
};
Tab3PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.ReactiveFormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forChild([{ path: '', component: _tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page }]),
            _tab3_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab3PageRoutingModule,
        ],
        providers: [_angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder],
        declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_0__.Tab3Page],
    })
], Tab3PageModule);



/***/ }),

/***/ 9648:
/*!*****************************************!*\
  !*** ./src/app/pages/tab3/tab3.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab3Page": () => (/* binding */ Tab3Page)
/* harmony export */ });
/* harmony import */ var _home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab3_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab3.page.html?ngResource */ 490);
/* harmony import */ var _tab3_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab3.page.scss?ngResource */ 8465);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_movies_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/movies.service */ 4550);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/camera */ 4241);











let Tab3Page = class Tab3Page {
  constructor(formBuilder, navCtrl, moviesService, sanitizer) {
    this.formBuilder = formBuilder;
    this.navCtrl = navCtrl;
    this.moviesService = moviesService;
    this.sanitizer = sanitizer;
    this.errorMessages = {
      location: [{
        type: 'required',
        message: 'Location is required'
      }, {
        type: 'minlength',
        message: 'Location must be at least 5 characters long'
      }, {
        type: 'maxlength',
        message: 'Location cannot be more than 100 characters long'
      }],
      title: [{
        type: 'required',
        message: 'Title is required'
      }, {
        type: 'minlength',
        message: 'Title must be at least 3 characters long'
      }, {
        type: 'maxlength',
        message: 'Title cannot be more than 200 characters long'
      }],
      rating: [{
        type: 'required',
        message: 'Rating is required'
      }, {
        type: 'min',
        message: 'Rating must be at least 1'
      }],
      genre: [{
        type: 'required',
        message: 'Genre is required'
      }, {
        type: 'minlength',
        message: 'Description must be at least 4 characters long'
      }, {
        type: 'maxlength',
        message: 'Genre cannot be more than 100 characters long'
      }],
      year: [{
        type: 'required',
        message: 'Year is required'
      }],
      poster: [{
        type: 'required',
        message: 'Poster is required'
      }]
    };
  }

  ngOnInit() {
    this.photo = '../../../assets/avatars/av-4.png';
    this.movieForm = this.formBuilder.group({
      location: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      rating: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[1-5]'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      title: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(200), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      genre: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      year: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      poster: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]))
    });
  }
  /**
   * submit the movie
   */


  submit(value) {
    var _this = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield (yield _this.moviesService.addMovie(value)).subscribe(() => {
        _this.navCtrl.navigateRoot('/main/tabs/tab1');
      });
    })();
  }

  getLocation() {
    var _this2 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const position = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();
      _this2.latitude = position.coords.latitude;
      _this2.longitude = position.coords.longitude;
      _this2.accuracy = position.coords.accuracy;
    })();
  }

  takePicture() {
    var _this3 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.Camera.getPhoto({
        quality: 100,
        allowEditing: false,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.CameraResultType.Uri
      });
      _this3.photo = _this3.sanitizer.bypassSecurityTrustResourceUrl(image && image.webPath);
    })();
  }

};

Tab3Page.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.NavController
}, {
  type: src_app_services_movies_service__WEBPACK_IMPORTED_MODULE_3__.MoviesService
}, {
  type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer
}];

Tab3Page = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-tab3',
  template: _tab3_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tab3_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab3Page);


/***/ }),

/***/ 8465:
/*!******************************************************!*\
  !*** ./src/app/pages/tab3/tab3.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWIzLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 490:
/*!******************************************************!*\
  !*** ./src/app/pages/tab3/tab3.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"primary\">\n    <ion-title> New Movie </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button [routerLink]=\"['/login']\">\n        <ion-icon name=\"person-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"movieForm\" (ngSubmit)=\"submit(movieForm.value)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Title</ion-label>\n        <ion-input\n          autocapitalize\n          type=\"text\"\n          formControlName=\"title\"\n          required\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.title\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('title').hasError(error.type) && (movieForm.get('title').dirty || movieForm.get('title').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Genre</ion-label>\n        <ion-input\n          autocapitalize\n          type=\"text\"\n          formControlName=\"genre\"\n          required\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.genre\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('genre').hasError(error.type) && (movieForm.get('genre').dirty || movieForm.get('genre').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Year</ion-label>\n        <ion-input type=\"text\" formControlName=\"year\" required></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.year\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('year').hasError(error.type) && (movieForm.get('year').dirty || movieForm.get('year').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Rating</ion-label>\n        <ion-input type=\"number\" formControlName=\"rating\" required></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.rating\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('rating').hasError(error.type) && (movieForm.get('rating').dirty || movieForm.get('rating').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Location</ion-label>\n        <ion-input type=\"text\" formControlName=\"location\" required></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.location\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('location').hasError(error.type) && (movieForm.get('location').dirty || movieForm.get('location').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Poster</ion-label>\n        <ion-input type=\"text\" formControlName=\"poster\" required></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.poster\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"movieForm.get('poster').hasError(error.type) && (movieForm.get('poster').dirty || movieForm.get('poster').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-button type=\"submit\" expand=\"block\" [disabled]=\"!movieForm.valid\">\n        <ion-icon slot=\"end\" name=\"cloud-upload-outline\"></ion-icon>\n      </ion-button>\n    </ion-list>\n  </form>\n\n  <ion-card>\n    <ion-card-content>\n      <img alt=\"Photo\" [src]=\"photo\" />\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"takePicture()\">\n      <ion-icon name=\"camera\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <div id=\"container\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-subtitle>Coordinates</ion-card-subtitle>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>Latitude: {{ latitude }}</ion-item>\n        <ion-item>Longitude: {{ longitude }}</ion-item>\n        <ion-item>Accuracy: {{ accuracy }}</ion-item>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/main/tabs/tab1\">\n        <ion-icon slot=\"start\" name=\"arrow-undo-outline\"></ion-icon>\n      </ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_tab3_tab3_module_ts.js.map