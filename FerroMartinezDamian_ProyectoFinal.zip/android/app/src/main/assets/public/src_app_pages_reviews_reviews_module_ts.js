"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_reviews_reviews_module_ts"],{

/***/ 1311:
/*!*********************************************************!*\
  !*** ./src/app/pages/reviews/reviews-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPageRoutingModule": () => (/* binding */ ReviewsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _reviews_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reviews.page */ 1539);




const routes = [
    {
        path: '',
        component: _reviews_page__WEBPACK_IMPORTED_MODULE_0__.ReviewsPage
    }
];
let ReviewsPageRoutingModule = class ReviewsPageRoutingModule {
};
ReviewsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ReviewsPageRoutingModule);



/***/ }),

/***/ 506:
/*!*************************************************!*\
  !*** ./src/app/pages/reviews/reviews.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPageModule": () => (/* binding */ ReviewsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _reviews_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reviews-routing.module */ 1311);
/* harmony import */ var _reviews_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reviews.page */ 1539);







let ReviewsPageModule = class ReviewsPageModule {
};
ReviewsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _reviews_routing_module__WEBPACK_IMPORTED_MODULE_0__.ReviewsPageRoutingModule,
        ],
        providers: [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder],
        declarations: [_reviews_page__WEBPACK_IMPORTED_MODULE_1__.ReviewsPage],
    })
], ReviewsPageModule);



/***/ }),

/***/ 1539:
/*!***********************************************!*\
  !*** ./src/app/pages/reviews/reviews.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReviewsPage": () => (/* binding */ ReviewsPage)
/* harmony export */ });
/* harmony import */ var _home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _reviews_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./reviews.page.html?ngResource */ 6291);
/* harmony import */ var _reviews_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reviews.page.scss?ngResource */ 6946);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _services_movies_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/movies.service */ 4550);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor/camera */ 4241);











let ReviewsPage = class ReviewsPage {
  constructor(modalCtrl, formBuilder, moviesService, sanitizer) {
    this.modalCtrl = modalCtrl;
    this.formBuilder = formBuilder;
    this.moviesService = moviesService;
    this.sanitizer = sanitizer;
    this.errorMessages = {
      reviewLocation: [{
        type: 'required',
        message: 'Location is required'
      }, {
        type: 'minlength',
        message: 'Location must be at least 5 characters long'
      }, {
        type: 'maxlength',
        message: 'Location cannot be more than 100 characters long'
      }],
      author: [{
        type: 'required',
        message: 'Author is required'
      }, {
        type: 'minlength',
        message: 'Author must be at least 3 characters long'
      }, {
        type: 'maxlength',
        message: 'Author cannot be more than 30 characters long'
      }],
      rating: [{
        type: 'required',
        message: 'Rating is required'
      }, {
        type: 'min',
        message: 'Rating must be at least 1'
      }],
      description: [{
        type: 'required',
        message: 'Description is required'
      }, {
        type: 'minlength',
        message: 'Description must be at least 4 characters long'
      }, {
        type: 'maxlength',
        message: 'Description cannot be more than 200 characters long'
      }]
    };
  }

  ngOnInit() {
    this.photo = '../../../assets/avatars/av-4.png';
    this.reviewForm = this.formBuilder.group({
      author: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(3), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(50), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      rating: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[1-5]'), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      description: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(200), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required])),
      reviewLocation: new _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(100), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]))
    });
  }

  back() {
    this.modalCtrl.dismiss();
  }
  /**
   * submit the review
   */


  submit(value) {
    this.moviesService.addReview(this.id, value).subscribe(() => {
      this.modalCtrl.dismiss();
    });
  }

  getLocation() {
    var _this = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const position = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();
      _this.latitude = position.coords.latitude;
      _this.longitude = position.coords.longitude;
      _this.accuracy = position.coords.accuracy;
    })();
  }

  takePicture() {
    var _this2 = this;

    return (0,_home_delia_Documentos_Master_movies2u_FrontEnd_movies2u_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.Camera.getPhoto({
        quality: 100,
        allowEditing: false,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_5__.CameraResultType.Uri
      });
      _this2.photo = _this2.sanitizer.bypassSecurityTrustResourceUrl(image && image.webPath);
    })();
  }

};

ReviewsPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.UntypedFormBuilder
}, {
  type: _services_movies_service__WEBPACK_IMPORTED_MODULE_3__.MoviesService
}, {
  type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer
}];

ReviewsPage.propDecorators = {
  id: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.Input
  }]
};
ReviewsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-reviews',
  template: _reviews_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_reviews_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ReviewsPage);


/***/ }),

/***/ 6946:
/*!************************************************************!*\
  !*** ./src/app/pages/reviews/reviews.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZXZpZXdzLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 6291:
/*!************************************************************!*\
  !*** ./src/app/pages/reviews/reviews.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"secondary\">\n    <ion-title>Movie Review</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <form [formGroup]=\"reviewForm\" (ngSubmit)=\"submit(reviewForm.value)\">\n    <ion-list>\n      <ion-item>\n        <ion-label position=\"floating\">Author</ion-label>\n        <ion-input\n          autocapitalize\n          type=\"text\"\n          formControlName=\"author\"\n          required\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.author\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('author').hasError(error.type) && (reviewForm.get('author').dirty || reviewForm.get('author').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Description</ion-label>\n        <ion-input\n          type=\"text\"\n          formControlName=\"description\"\n          required\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.description\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('description').hasError(error.type) && (reviewForm.get('description').dirty || reviewForm.get('description').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Rating</ion-label>\n        <ion-input type=\"number\" formControlName=\"rating\" required></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.rating\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('rating').hasError(error.type) && (reviewForm.get('rating').dirty || reviewForm.get('rating').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-item>\n        <ion-label position=\"floating\">Location</ion-label>\n        <ion-input\n          type=\"text\"\n          formControlName=\"reviewLocation\"\n          required\n          (ionChange)=\"getLocation()\"\n          [debounce]=\"500\"\n        ></ion-input>\n      </ion-item>\n      <div>\n        <ng-container *ngFor=\"let error of errorMessages.reviewLocation\">\n          <small\n            class=\"error-message\"\n            *ngIf=\"reviewForm.get('reviewLocation').hasError(error.type) && (reviewForm.get('reviewLocation').dirty || reviewForm.get('reviewLocation').touched)\"\n            >{{error.message}}</small\n          >\n        </ng-container>\n      </div>\n      <ion-button type=\"submit\" expand=\"block\" [disabled]=\"!reviewForm.valid\">\n        <ion-icon slot=\"end\" name=\"cloud-upload-outline\"></ion-icon>\n      </ion-button>\n    </ion-list>\n  </form>\n\n  <ion-card>\n    <ion-card-content>\n      <img alt=\"Photo\" [src]=\"photo\" />\n    </ion-card-content>\n  </ion-card>\n\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"takePicture()\">\n      <ion-icon name=\"camera\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n\n  <div id=\"container\">\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>Coordinates</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>Latitude: {{ latitude }}</ion-item>\n        <ion-item>Longitude: {{ longitude }}</ion-item>\n        <ion-item>Accuracy: {{ accuracy }}</ion-item>\n      </ion-card-content>\n    </ion-card>\n  </div>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon slot=\"start\" name=\"arrow-undo-outline\"></ion-icon>\n        <ion-label>Back</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_reviews_reviews_module_ts.js.map