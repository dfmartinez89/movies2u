export const environment = {
  production: true,
  apiUrl: 'https://movies2uexpress-xqmie7qm3a-uc.a.run.app/movies',
  apiSearchUrl: 'https://movies2uexpress-xqmie7qm3a-uc.a.run.app/search',
  apiLoginUrl: 'https://movies2uexpress-xqmie7qm3a-uc.a.run.app/users/login',
  baseUrl: 'https://movies2uexpress-xqmie7qm3a-uc.a.run.app',

};
